 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mbali.java.part1;

/**
 *
 * @author Student
 */
public class Login {
    
    String registeredUsername ;
    String registeredPassword ;
    String registeredCellPhoneNumber ;
    String registeredFirstName;
    String registeredLastName;
    
    //Check if username is correctly formatted
    public boolean checkUserName(String username) {
        return username.contains("_") && username.length()<=5;
    }
    
    //Check if password is correctly formated
    public boolean checkPasswordComplexity(String password){
        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecialCharacter = false;
        
        if (password.length() >=8) {
            
            for (int i = 0; i < password.length();i++) {
                char character = password.charAt (i);
                
                if (Character.isUpperCase (character)) {
                    hasCapital = true ;
                }
                if (Character.isDigit(character)){
                    hasNumber = true ;
                }
               if (!Character.isLetterOrDigit(character)) {
                   hasSpecialCharacter = true;
               }
            }
        }
        return password.length()>=8
                && hasCapital
                && hasNumber
                && hasSpecialCharacter;
    }
    //Check South African cellphone number
    public boolean checkCellPhoneNumber(String cellPhoneNumber) {
        return cellPhoneNumber.matches ("^\\+27\\d{9}$");
    }
    //Register the user 
    public String registerUser(String username , String password, String cellPhoneNumber , String firstName , String lastName){
        
        registeredUsername = username ;
        registeredPassword = password ;
        registeredCellPhoneNumber = cellPhoneNumber ;
        registeredFirstName = firstName ;
        registeredLastName = lastName ; 
        
        return "User registered successfully" ;
    }
        //Check login details
       public boolean loginUser(String username ,String password){
           return username.equals(registeredUsername)
                   && password.equals(registeredPassword);
       }
       //Display log in status
       public String returnLoginStatus(boolean isLoggedIn,String firstName , String lastName){
           
           if ( isLoggedIn) {
               return "Welcome" + firstName + "" + lastName + ",it is great to see you again";
           }else{
               return "Username or password incorrect , please try again";
           }
    }
    
}
