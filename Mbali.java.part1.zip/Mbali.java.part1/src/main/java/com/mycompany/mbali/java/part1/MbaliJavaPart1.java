 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mbali.java.part1;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class MbaliJavaPart1 {

    public static void main(String[] args) {
        //Declaration
        String firstName;
        String lastName;
        String username;
        String password;
        String cellPhoneNumber;
        String registraMessage;
        
        
        Scanner myInput =new Scanner (System.in);
            Login loginSystem=new Login ();
            
            System.out.println("======REGISTRATION======");
            
            //Ask user for their first name
            
           System.out.print("Enter your first name: ");
           firstName = myInput.nextLine();
           
           //Ask user for their last name
           System.out.print("Enter your last name: ");
           lastName = myInput.nextLine();
           
           //Ask user for their username
           System.out.println("Your username must contain an underscore'_'and maximum 5 characters");
           System.out.print("Enter your username: ");
           username = myInput.nextLine();
           
           //Keep asking user until username is correct
           while (!loginSystem.checkUserName(username)) {
           
           System.out.println("Username is incorrectly formatted.");
          
           
           System.out.print("Enter your username again :");
           username = myInput.nextLine();
    }
           
           //Ask user for password
           System.out.print("Your password must contain minimum of 8 characters , 1 capital letter,a number ,a special character");
           System.out.print("Enter your password: ");
           password = myInput.nextLine();
           
           //Keep asking until password is correct
           while (!loginSystem.checkPasswordComplexity(password)){
               System.out.println("Password is incorrectly formatted .");
               System.out.println("Please make sure it has 8 characters , a number, capital letter ,a special character");
           
               System .out.println("Enter your password again :");
               password = myInput.nextLine();
           } 
               
           //Ask user for their cell phone number
           System.out.print("Enter your South African cellphone numbe (eg;+27714639386)");
           cellPhoneNumber = myInput.nextLine();
           
           System.out.print("Enter your cellphone number:");
           cellPhoneNumber = myInput.nextLine();
           
           //Keep asking until cellphone is correctly formatted
           while (!loginSystem.checkCellPhoneNumber(cellPhoneNumber)) {
          System.out.println("Cell phone number is incorrectly formatted.");
          System.out.println("Please enter it using +27 followed by 9 numbers");
          
          System.out.print("Enter your cell phone number again :");
          cellPhoneNumber = myInput.nextLine();
           }
           
           //Register user
           registraMessage = loginSystem.registerUser(
                   username,
                   password,
                   cellPhoneNumber,
                   firstName,
                   lastName
           );
           System.out.println("registraMessage");
           
           //Login
           if (registraMessage.equals("User registered successfully ")){
               
               System.out.println("====LOGIN====");
               
               System.out.print("Enter username :");
               String loginUsername = myInput.nextLine();
               
               System.out.print("Enter password :");
               String loginPassword = myInput.nextLine();
               
               //Check login
               boolean isLoggedIn = loginSystem.loginUser(
                       loginUsername,
                       loginPassword
               );
               
               //Display login status
               System.out.println(
                       loginSystem.returnLoginStatus(
                               isLoggedIn,
                               firstName,
                               lastName
                       )
               );
               
           
           }
        myInput.close();
    }
}
